# Changelog
All notable changes to this project will be documented in this file.

## 1.0.0 - 21.07.2023

Initial release
