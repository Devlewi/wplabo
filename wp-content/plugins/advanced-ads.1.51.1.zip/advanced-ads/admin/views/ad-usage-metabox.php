<?php
/**
 * Render the Usage meta box on the ad edit screen
 */
?>
<div id="advads-ad-usage" class="advads-option-list">
	<?php
	include ADVADS_ABSPATH . 'admin/views/ad-usage-notes.php';
	include ADVADS_ABSPATH . 'admin/views/ad-usage.php';
	?>
</div>
