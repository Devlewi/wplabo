<p class="advads-conditions-not-selected advads-notice-inline advads-error">
	<?php echo esc_html_x( 'Please select some items.', 'Error message shown when no display condition term is selected', 'advanced-ads' ); ?>
</p>
