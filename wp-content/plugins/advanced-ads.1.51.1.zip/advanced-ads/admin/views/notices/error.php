<div class="notice notice-error advads-notice advads-admin-notice is-dismissible" data-notice="<?php echo $_notice; ?>"><p><?php echo $text; ?></p></div>
