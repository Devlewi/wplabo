<a href="<?php echo esc_url( $url ); ?>" target="_blank"><?php echo esc_html( $title ); ?></a>
