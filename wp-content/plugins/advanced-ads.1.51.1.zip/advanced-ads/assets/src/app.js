import jQuery from 'jquery';

import OneclickSettings from './modules/oneclick';

jQuery(() => {
	OneclickSettings();
});
