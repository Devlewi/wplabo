import connectButton from './connect-button';
import settingsUi from './settings';

export default function () {
	connectButton();
	settingsUi();
}
